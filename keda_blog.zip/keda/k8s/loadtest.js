import http from 'k6/http';
import { sleep } from 'k6';

export default function () {
  http.get('http://function-helloworld.francecentral.cloudapp.azure.com/helloworld/api/helloworld?name=yaya');
  sleep(1);
}

