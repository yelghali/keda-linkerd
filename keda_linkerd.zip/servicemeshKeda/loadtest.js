import http from 'k6/http';
import { sleep } from 'k6';

export default function () {
  http.get('http://servicemesh.demo/home/');
  sleep(0.5);
  http.get('http://servicemesh.demo/api/playlists');
}

